import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { files } from "@db/schema";
import { storage } from "./lib/storage";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";

export const storageRouter = createRouter({
  uploadImage: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(160),
        contentBase64: z.string().max(14_000_000),
        contentType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
      if (bytes.byteLength > 8 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE" });
      const safeName = input.name.replace(/[^a-zA-Z0-9._-]/g, "-");
      const saved = await storage.uploadFile({
        fileContent: bytes,
        fileName: `u/${ctx.user.id}/posts/${Date.now()}-${safeName}`,
        contentType: input.contentType,
      });
      await getDb().insert(files).values({
        key: saved.key,
        ownerId: ctx.user.id,
        name: saved.fileName,
        size: saved.size,
      });
      return { key: saved.key, size: saved.size };
    }),

  removeImage: authedQuery.input(z.object({ key: z.string() })).mutation(async ({ ctx, input }) => {
    const file = await getDb().query.files.findFirst({
      where: and(eq(files.key, input.key), eq(files.ownerId, ctx.user.id)),
    });
    if (!file) throw new TRPCError({ code: "NOT_FOUND" });
    await getDb().delete(files).where(eq(files.id, file.id));
    return { ok: await storage.deleteFile({ fileKey: file.key }) };
  }),
});
