import { randomBytes, scrypt as scryptCallback, timingSafeEqual, createHash } from "node:crypto";
import { promisify } from "node:util";
import { parse, serialize } from "cookie";
import { and, eq, gt } from "drizzle-orm";
import { sessions, users, type User } from "@db/schema";
import { getDb } from "./queries/connection";

const scrypt = promisify(scryptCallback);
export const ACCOUNT_COOKIE = "aetheris_session";
const SESSION_SECONDS = 60 * 60 * 24 * 30;

export function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  const expected = Buffer.from(key, "hex");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

export function hasActivePlus(user: Pick<User, "plan" | "planExpiresAt">) {
  return user.plan === "plus" && (!user.planExpiresAt || user.planExpiresAt > new Date());
}

export function publicUser(user: User) {
  return {
    id: user.id,
    handle: user.handle ?? "uye",
    name: user.name ?? "Aetheris Üyesi",
    email: user.email,
    avatar: user.avatar,
    bio: user.bio,
    role: user.role,
    isVerified: user.isVerified,
    isPrivate: user.isPrivate,
    plan: hasActivePlus(user) ? "plus" as const : "free" as const,
    planExpiresAt: user.planExpiresAt,
    createdAt: user.createdAt,
  };
}

export async function createAccountSession(userId: number, headers: Headers) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_SECONDS * 1000);
  await getDb().insert(sessions).values({ userId, tokenHash: hashToken(token), expiresAt });
  headers.append(
    "Set-Cookie",
    serialize(ACCOUNT_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: SESSION_SECONDS,
    }),
  );
}

export async function authenticateAccountRequest(headers: Headers): Promise<User | undefined> {
  const token = parse(headers.get("cookie") ?? "")[ACCOUNT_COOKIE];
  if (!token) return undefined;
  const rows = await getDb()
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return rows[0]?.user;
}

export async function destroyAccountSession(headers: Headers, responseHeaders: Headers) {
  const token = parse(headers.get("cookie") ?? "")[ACCOUNT_COOKIE];
  if (token) {
    await getDb().delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  }
  responseHeaders.append(
    "Set-Cookie",
    serialize(ACCOUNT_COOKIE, "", {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 0,
    }),
  );
}
