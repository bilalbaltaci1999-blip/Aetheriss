import { randomBytes } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { notifications, orders, platformSettings, supportTickets, users } from "@db/schema";
import { createRouter, adminQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { hasActivePlus } from "./account-auth";

export const PLANS = {
  plus_monthly: { amount: 12900, label: "Aetheris Plus · Aylık", months: 1 },
  plus_yearly: { amount: 129000, label: "Aetheris Plus · Yıllık", months: 12 },
} as const;

async function paymentDetails() {
  const row = await getDb().query.platformSettings.findFirst({ where: eq(platformSettings.key, "bank_transfer") });
  if (!row) return { accountName: "", bankName: "", iban: "" };
  try {
    return JSON.parse(row.value) as { accountName: string; bankName: string; iban: string };
  } catch {
    return { accountName: "", bankName: "", iban: "" };
  }
}

export const commerceRouter = createRouter({
  plans: authedQuery.query(() => PLANS),
  paymentDetails: authedQuery.query(() => paymentDetails()),

  myOrders: authedQuery.query(({ ctx }) =>
    getDb().select().from(orders).where(eq(orders.userId, ctx.user.id)).orderBy(desc(orders.createdAt)),
  ),

  createOrder: authedQuery
    .input(z.object({ plan: z.enum(["plus_monthly", "plus_yearly"]) }))
    .mutation(async ({ ctx, input }) => {
      const plan = PLANS[input.plan];
      const referenceCode = `AE-${randomBytes(4).toString("hex").toUpperCase()}`;
      await getDb().insert(orders).values({
        userId: ctx.user.id,
        referenceCode,
        plan: input.plan,
        amount: plan.amount,
      });
      return { referenceCode, amount: plan.amount, payment: await paymentDetails() };
    }),

  markPaymentSent: authedQuery.input(z.object({ orderId: z.number() })).mutation(async ({ ctx, input }) => {
    const order = await getDb().query.orders.findFirst({ where: eq(orders.id, input.orderId) });
    if (!order || order.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
    if (order.status !== "awaiting_payment") throw new TRPCError({ code: "BAD_REQUEST" });
    await getDb().update(orders).set({ status: "pending_review" }).where(eq(orders.id, order.id));
    return { ok: true };
  }),

  adminOrders: adminQuery.query(() =>
    getDb()
      .select({ order: orders, user: users })
      .from(orders)
      .innerJoin(users, eq(orders.userId, users.id))
      .orderBy(desc(orders.createdAt))
      .limit(100),
  ),

  approveOrder: adminQuery.input(z.object({ orderId: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    const order = await db.query.orders.findFirst({ where: eq(orders.id, input.orderId) });
    if (!order || order.status === "active") throw new TRPCError({ code: "BAD_REQUEST" });
    const user = await db.query.users.findFirst({ where: eq(users.id, order.userId) });
    if (!user) throw new TRPCError({ code: "NOT_FOUND" });
    const months = PLANS[order.plan].months;
    const base = user.planExpiresAt && user.planExpiresAt > new Date() ? user.planExpiresAt : new Date();
    const expires = new Date(base);
    expires.setMonth(expires.getMonth() + months);
    await db.transaction(async (tx) => {
      await tx.update(orders).set({ status: "active", reviewedAt: new Date() }).where(eq(orders.id, order.id));
      await tx
        .update(users)
        .set({ plan: "plus", isVerified: true, planExpiresAt: expires })
        .where(eq(users.id, user.id));
      await tx.insert(notifications).values({
        userId: user.id,
        title: "Aetheris Plus aktif",
        body: `${PLANS[order.plan].label} ödemen onaylandı. Mavi tik ve Plus özellikleri hesabına eklendi.`,
        kind: "billing",
      });
    });
    return { ok: true };
  }),

  rejectOrder: adminQuery.input(z.object({ orderId: z.number() })).mutation(async ({ input }) => {
    await getDb()
      .update(orders)
      .set({ status: "rejected", reviewedAt: new Date() })
      .where(eq(orders.id, input.orderId));
    return { ok: true };
  }),

  savePaymentDetails: adminQuery
    .input(
      z.object({
        accountName: z.string().trim().min(2).max(120),
        bankName: z.string().trim().min(2).max(120),
        iban: z.string().trim().min(16).max(40),
      }),
    )
    .mutation(async ({ input }) => {
      const value = JSON.stringify({ ...input, iban: input.iban.replaceAll(" ", "").toUpperCase() });
      await getDb()
        .insert(platformSettings)
        .values({ key: "bank_transfer", value })
        .onDuplicateKeyUpdate({ set: { value } });
      return { ok: true };
    }),

  adminStats: adminQuery.query(async () => {
    const db = getDb();
    const [allUsers, allOrders, allTickets] = await Promise.all([
      db.select({ id: users.id, plan: users.plan, planExpiresAt: users.planExpiresAt, isVerified: users.isVerified }).from(users),
      db.select().from(orders),
      db.select().from(supportTickets),
    ]);
    return {
      users: allUsers.length,
      plusUsers: allUsers.filter((user) => hasActivePlus(user)).length,
      verifiedUsers: allUsers.filter((user) => user.isVerified).length,
      pendingOrders: allOrders.filter((order) => order.status === "pending_review").length,
      approvedRevenue: allOrders
        .filter((order) => order.status === "active")
        .reduce((sum, order) => sum + order.amount, 0),
      openTickets: allTickets.filter((ticket) => ticket.status === "open").length,
    };
  }),
});
