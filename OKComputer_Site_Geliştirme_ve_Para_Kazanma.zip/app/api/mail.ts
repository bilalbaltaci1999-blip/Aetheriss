import nodemailer from "nodemailer";
import { log } from "./lib/logger";

export function isMailConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_FROM);
}

export async function sendPasswordResetEmail(to: string, resetUrl: string) {
  if (!isMailConfigured()) return false;
  const port = Number(process.env.SMTP_PORT ?? 587);
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined,
  });
  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to,
      subject: "Aetheris şifre sıfırlama bağlantın",
      text: `Şifreni sıfırlamak için bu bağlantıyı aç: ${resetUrl}\n\nBağlantı 30 dakika geçerlidir ve yalnızca bir kez kullanılabilir. Bu isteği sen yapmadıysan bu e-postayı yok say.`,
      html: `<div style="font-family:Arial,sans-serif;background:#121212;color:#ffffff;padding:32px"><div style="max-width:520px;margin:auto"><p style="color:#40aaff;font-weight:bold;letter-spacing:2px">AETHERIS</p><h1>Şifreni yenile</h1><p style="line-height:1.6;color:#d4d4d4">Aşağıdaki düğmeyle yeni bir şifre belirleyebilirsin. Bağlantı 30 dakika geçerlidir ve yalnızca bir kez kullanılabilir.</p><p><a href="${resetUrl}" style="display:inline-block;background:#40aaff;color:#121212;text-decoration:none;font-weight:bold;padding:14px 22px;border-radius:6px">Şifreyi sıfırla</a></p><p style="font-size:12px;color:#a3a3a3">Bu isteği sen yapmadıysan bu e-postayı yok say.</p></div></div>`,
    });
    return true;
  } catch (error) {
    log.error("password reset email failed", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}
