import { accountRouter } from "./account-router";
import { authRouter } from "./auth-router";
import { commerceRouter } from "./commerce-router";
import { socialRouter } from "./social-router";
import { storageRouter } from "./storage-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  account: accountRouter,
  social: socialRouter,
  commerce: commerceRouter,
  storage: storageRouter,
});

export type AppRouter = typeof appRouter;
