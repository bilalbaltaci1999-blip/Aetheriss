import { eq } from "drizzle-orm";
import { messages, notifications, posts, users } from "@db/schema";
import { hashPassword } from "../account-auth";
import { getDb } from "./connection";

const avatar = (seed: string) =>
  `https://api.dicebear.com/9.x/notionists-neutral/svg?seed=${encodeURIComponent(seed)}`;

export async function ensureSeedData() {
  const db = getDb();
  const existing = await db.query.users.findFirst({ where: eq(users.handle, "aetheris") });
  if (existing) return;

  const passwordHash = await hashPassword("Demo123!");
  const [{ id: officialId }] = await db
    .insert(users)
    .values({
      unionId: "seed:official",
      handle: "aetheris",
      name: "Aetheris",
      email: "hello@aetheris.social",
      avatar: avatar("aetheris-official"),
      bio: "Üretken insanlar için sakin, güvenli ve kazançlı sosyal alan.",
      isVerified: true,
    })
    .$returningId();
  const [{ id: demoId }] = await db
    .insert(users)
    .values({
      unionId: "seed:demo",
      handle: "demo",
      name: "Deniz Aksoy",
      email: "demo@aetheris.social",
      passwordHash,
      avatar: avatar("deniz-aksoy"),
      bio: "Ürün tasarımcısı. Daha iyi dijital alışkanlıklar ve yaratıcı işler peşinde.",
      isVerified: true,
      plan: "plus",
      planExpiresAt: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000),
    })
    .$returningId();
  const [{ id: selinId }] = await db
    .insert(users)
    .values({
      unionId: "seed:selin",
      handle: "selinyazici",
      name: "Selin Yazıcı",
      avatar: avatar("selin-yazici"),
      bio: "Fotoğraf, şehir kültürü ve bağımsız yayıncılık.",
      isVerified: true,
    })
    .$returningId();
  const [{ id: emreId }] = await db
    .insert(users)
    .values({
      unionId: "seed:emre",
      handle: "emrekeskin",
      name: "Emre Keskin",
      avatar: avatar("emre-keskin"),
      bio: "Geliştirici, açık kaynak meraklısı ve hafta sonu bisikletçisi.",
    })
    .$returningId();

  await db.insert(posts).values([
    {
      authorId: officialId,
      content:
        "Aetheris Plus artık daha kapsamlı: mavi doğrulama rozeti, uzun gönderiler, gelişmiş profil analizi ve öncelikli destek tek üyelikte. #AetherisPlus",
      imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&q=85",
      createdAt: new Date(Date.now() - 18 * 60 * 1000),
    },
    {
      authorId: selinId,
      content:
        "Bir topluluğu büyütmenin en iyi yolu daha çok gürültü değil, daha nitelikli sohbetler kurmak. Bugün yeni fotoğraf serimin notlarını paylaşıyorum. #üretim",
      imageUrl: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200&q=85",
      createdAt: new Date(Date.now() - 72 * 60 * 1000),
    },
    {
      authorId: emreId,
      content:
        "Hafta sonu projesi: Daha az ekran süresi, daha çok işe yarar bağlantı. Açık kaynak listemi Keşfet bölümündeki başlık altında topladım.",
      createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
    },
  ]);

  await db.insert(notifications).values([
    {
      userId: demoId,
      title: "Plus üyeliğin aktif",
      body: "Mavi tik ve tüm Plus ayrıcalıkları hesabında kullanılabilir.",
      kind: "billing",
    },
    {
      userId: demoId,
      title: "Yeni topluluk notu",
      body: "Aetheris, daha nitelikli etkileşim için akış sıralamasını yeniledi.",
      kind: "system",
    },
  ]);
  await db.insert(messages).values({
    senderId: officialId,
    recipientId: demoId,
    content: "Aetheris'e hoş geldin. Bir sorun olursa Destek bölümünden bize ulaşabilirsin.",
  });
}
