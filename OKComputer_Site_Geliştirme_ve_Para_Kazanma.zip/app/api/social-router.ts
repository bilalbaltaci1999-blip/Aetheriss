import { TRPCError } from "@trpc/server";
import { and, desc, eq, inArray, ne, or } from "drizzle-orm";
import { z } from "zod";
import {
  bookmarks,
  comments,
  files,
  likes,
  messages,
  notifications,
  posts,
  supportTickets,
  users,
} from "@db/schema";
import { storage } from "./lib/storage";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { hasActivePlus } from "./account-auth";
import { ensureSeedData } from "./queries/seed";

async function resolvePostImage(imageKey: string | null, imageUrl: string | null) {
  if (imageUrl) return imageUrl;
  if (!imageKey) return null;
  try {
    return (await storage.getPresignedUrl({ key: imageKey })).url;
  } catch {
    return null;
  }
}

export const socialRouter = createRouter({
  feed: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    const db = getDb();
    const rows = await db
      .select({ post: posts, author: users })
      .from(posts)
      .innerJoin(users, eq(posts.authorId, users.id))
      .orderBy(desc(posts.createdAt))
      .limit(60);
    if (!rows.length) return [];
    const ids = rows.map((row) => row.post.id);
    const [allLikes, allComments, allBookmarks] = await Promise.all([
      db.select().from(likes).where(inArray(likes.postId, ids)),
      db.select().from(comments).where(inArray(comments.postId, ids)),
      db.select().from(bookmarks).where(inArray(bookmarks.postId, ids)),
    ]);
    return Promise.all(
      rows.map(async ({ post, author }) => ({
        id: post.id,
        content: post.content,
        imageUrl: await resolvePostImage(post.imageKey, post.imageUrl),
        createdAt: post.createdAt,
        author: {
          id: author.id,
          name: author.name ?? "Aetheris Üyesi",
          handle: author.handle ?? "uye",
          avatar: author.avatar,
          isVerified: author.isVerified,
        },
        likeCount: allLikes.filter((like) => like.postId === post.id).length,
        commentCount: allComments.filter((comment) => comment.postId === post.id).length,
        liked: allLikes.some((like) => like.postId === post.id && like.userId === ctx.user.id),
        bookmarked: allBookmarks.some((mark) => mark.postId === post.id && mark.userId === ctx.user.id),
      })),
    );
  }),

  createPost: authedQuery
    .input(z.object({ content: z.string().trim().min(1).max(1200), imageKey: z.string().max(600).optional() }))
    .mutation(async ({ ctx, input }) => {
      const maxLength = hasActivePlus(ctx.user) ? 1200 : 500;
      if (input.content.length > maxLength) throw new TRPCError({ code: "BAD_REQUEST", message: `Ücretsiz hesaplarda gönderiler en fazla ${maxLength} karakter olabilir.` });
      if (input.imageKey) {
        const owned = await getDb().query.files.findFirst({ where: eq(files.key, input.imageKey) });
        if (!owned || owned.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      }
      await getDb().insert(posts).values({
        authorId: ctx.user.id,
        content: input.content,
        imageKey: input.imageKey,
      });
      return { ok: true };
    }),

  toggleLike: authedQuery.input(z.object({ postId: z.number() })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const existing = await db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, input.postId), eq(likes.userId, ctx.user.id)))
      .limit(1);
    if (existing.length) {
      await db.delete(likes).where(eq(likes.id, existing[0].id));
      return { liked: false };
    }
    await db.insert(likes).values({ postId: input.postId, userId: ctx.user.id });
    return { liked: true };
  }),

  toggleBookmark: authedQuery.input(z.object({ postId: z.number() })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const existing = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.postId, input.postId), eq(bookmarks.userId, ctx.user.id)))
      .limit(1);
    if (existing.length) {
      await db.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
      return { bookmarked: false };
    }
    await db.insert(bookmarks).values({ postId: input.postId, userId: ctx.user.id });
    return { bookmarked: true };
  }),

  comments: authedQuery.input(z.object({ postId: z.number() })).query(async ({ input }) => {
    return getDb()
      .select({ comment: comments, author: users })
      .from(comments)
      .innerJoin(users, eq(comments.authorId, users.id))
      .where(eq(comments.postId, input.postId))
      .orderBy(desc(comments.createdAt));
  }),

  addComment: authedQuery
    .input(z.object({ postId: z.number(), content: z.string().trim().min(1).max(500) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(comments).values({
        postId: input.postId,
        authorId: ctx.user.id,
        content: input.content,
      });
      return { ok: true };
    }),

  people: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    return getDb()
      .select({
        id: users.id,
        name: users.name,
        handle: users.handle,
        avatar: users.avatar,
        bio: users.bio,
        isVerified: users.isVerified,
      })
      .from(users)
      .where(ne(users.id, ctx.user.id))
      .limit(12);
  }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(80),
        handle: z.string().trim().toLowerCase().regex(/^[a-z0-9_]{3,24}$/),
        bio: z.string().trim().max(240),
        avatar: z.string().url().or(z.literal("")),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const duplicate = await getDb()
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.handle, input.handle), ne(users.id, ctx.user.id)))
        .limit(1);
      if (duplicate.length) throw new TRPCError({ code: "CONFLICT", message: "Bu kullanıcı adı kullanılıyor." });
      await getDb()
        .update(users)
        .set({ ...input, avatar: input.avatar || ctx.user.avatar })
        .where(eq(users.id, ctx.user.id));
      return { ok: true };
    }),

  updatePrivacy: authedQuery.input(z.object({ isPrivate: z.boolean() })).mutation(async ({ ctx, input }) => {
    await getDb().update(users).set({ isPrivate: input.isPrivate }).where(eq(users.id, ctx.user.id));
    return { ok: true };
  }),

  conversations: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    return getDb()
      .select({ id: users.id, name: users.name, handle: users.handle, avatar: users.avatar, isVerified: users.isVerified })
      .from(users)
      .where(ne(users.id, ctx.user.id))
      .limit(10);
  }),

  conversation: authedQuery.input(z.object({ userId: z.number() })).query(async ({ ctx, input }) => {
    return getDb()
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, ctx.user.id), eq(messages.recipientId, input.userId)),
          and(eq(messages.senderId, input.userId), eq(messages.recipientId, ctx.user.id)),
        ),
      )
      .orderBy(messages.createdAt);
  }),

  sendMessage: authedQuery
    .input(z.object({ recipientId: z.number(), content: z.string().trim().min(1).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(messages).values({
        senderId: ctx.user.id,
        recipientId: input.recipientId,
        content: input.content,
      });
      return { ok: true };
    }),

  notifications: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    return getDb()
      .select()
      .from(notifications)
      .where(eq(notifications.userId, ctx.user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(40);
  }),

  markNotificationsRead: authedQuery.mutation(async ({ ctx }) => {
    await getDb().update(notifications).set({ readAt: new Date() }).where(eq(notifications.userId, ctx.user.id));
    return { ok: true };
  }),

  tickets: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.userId, ctx.user.id))
      .orderBy(desc(supportTickets.createdAt));
  }),

  createTicket: authedQuery
    .input(z.object({ subject: z.string().trim().min(3).max(160), message: z.string().trim().min(10).max(3000) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(supportTickets).values({ userId: ctx.user.id, ...input });
      return { ok: true };
    }),
});
