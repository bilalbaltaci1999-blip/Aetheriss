import { randomBytes } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { and, eq, gt, isNull, or } from "drizzle-orm";
import { z } from "zod";
import { passwordResetTokens, sessions, users } from "@db/schema";
import {
  createAccountSession,
  destroyAccountSession,
  hashPassword,
  hashToken,
  publicUser,
  verifyPassword,
} from "./account-auth";
import { isMailConfigured, sendPasswordResetEmail } from "./mail";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { ensureSeedData } from "./queries/seed";

const passwordSchema = z
  .string()
  .min(8, "Şifre en az 8 karakter olmalı")
  .max(72)
  .regex(/[A-Z]/, "En az bir büyük harf kullan")
  .regex(/[0-9]/, "En az bir rakam kullan");

export const accountRouter = createRouter({
  me: publicQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    return ctx.user ? publicUser(ctx.user) : null;
  }),

  register: publicQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(80),
        handle: z
          .string()
          .trim()
          .toLowerCase()
          .regex(/^[a-z0-9_]{3,24}$/, "Kullanıcı adı 3–24 harf, rakam veya _ olabilir"),
        email: z.string().trim().toLowerCase().email().max(320),
        password: passwordSchema,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db
        .select({ id: users.id })
        .from(users)
        .where(or(eq(users.email, input.email), eq(users.handle, input.handle)))
        .limit(1);
      if (existing.length) {
        throw new TRPCError({ code: "CONFLICT", message: "Bu e-posta veya kullanıcı adı zaten kayıtlı." });
      }
      const [{ id }] = await db
        .insert(users)
        .values({
          unionId: `local:${randomBytes(16).toString("hex")}`,
          handle: input.handle,
          name: input.name,
          email: input.email,
          passwordHash: await hashPassword(input.password),
          avatar: `https://api.dicebear.com/9.x/notionists-neutral/svg?seed=${encodeURIComponent(input.handle)}`,
          bio: "Aetheris'e yeni katıldı.",
        })
        .$returningId();
      await createAccountSession(id, ctx.resHeaders);
      const user = await db.query.users.findFirst({ where: eq(users.id, id) });
      return publicUser(user!);
    }),

  login: publicQuery
    .input(z.object({ identifier: z.string().trim().min(1).max(320), password: z.string().min(1).max(72) }))
    .mutation(async ({ ctx, input }) => {
      const identifier = input.identifier.replace(/^@/, "").toLowerCase();
      const user = await getDb().query.users.findFirst({
        where: or(eq(users.email, identifier), eq(users.handle, identifier)),
      });
      if (!user?.passwordHash || !(await verifyPassword(input.password, user.passwordHash))) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "E-posta/kullanıcı adı veya şifre hatalı." });
      }
      await getDb().update(users).set({ lastSignInAt: new Date() }).where(eq(users.id, user.id));
      await createAccountSession(user.id, ctx.resHeaders);
      return publicUser(user);
    }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    await destroyAccountSession(ctx.req.headers, ctx.resHeaders);
    return { ok: true };
  }),

  forgotPassword: publicQuery
    .input(z.object({ email: z.string().trim().toLowerCase().email() }))
    .mutation(async ({ ctx, input }) => {
      const user = await getDb().query.users.findFirst({ where: eq(users.email, input.email) });
      let previewUrl: string | undefined;
      if (user?.passwordHash) {
        const token = randomBytes(32).toString("base64url");
        await getDb().insert(passwordResetTokens).values({
          userId: user.id,
          tokenHash: hashToken(token),
          expiresAt: new Date(Date.now() + 30 * 60 * 1000),
        });
        const resetUrl = `${new URL(ctx.req.url).origin}/?reset=${encodeURIComponent(token)}`;
        const sent = await sendPasswordResetEmail(input.email, resetUrl);
        if (!sent && !isMailConfigured() && process.env.NODE_ENV !== "production") previewUrl = resetUrl;
      }
      return {
        ok: true,
        message: "Bu e-posta kayıtlıysa şifre sıfırlama bağlantısı gönderildi.",
        previewUrl,
      };
    }),

  resetPassword: publicQuery
    .input(z.object({ token: z.string().min(20), password: passwordSchema }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const tokenHash = hashToken(input.token);
      const reset = await db.query.passwordResetTokens.findFirst({
        where: and(
          eq(passwordResetTokens.tokenHash, tokenHash),
          isNull(passwordResetTokens.usedAt),
          gt(passwordResetTokens.expiresAt, new Date()),
        ),
      });
      if (!reset) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Bağlantı geçersiz veya süresi dolmuş." });
      }
      await db.transaction(async (tx) => {
        await tx
          .update(users)
          .set({ passwordHash: await hashPassword(input.password) })
          .where(eq(users.id, reset.userId));
        await tx
          .update(passwordResetTokens)
          .set({ usedAt: new Date() })
          .where(eq(passwordResetTokens.id, reset.id));
        await tx.delete(sessions).where(eq(sessions.userId, reset.userId));
      });
      return { ok: true };
    }),

  changePassword: publicQuery
    .input(z.object({ currentPassword: z.string(), newPassword: passwordSchema }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      if (!ctx.user.passwordHash || !(await verifyPassword(input.currentPassword, ctx.user.passwordHash))) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Mevcut şifre hatalı." });
      }
      await getDb()
        .update(users)
        .set({ passwordHash: await hashPassword(input.newPassword) })
        .where(eq(users.id, ctx.user.id));
      return { ok: true };
    }),
});
