import { useState, type FormEvent, type ReactNode } from "react";
import { Bookmark, Heart, MessageCircle, Send, Share2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { relativeTime } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { FeedPost } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";

function contentWithTags(content: string): ReactNode[] {
  return content.split(/(#[\p{L}\p{N}_]+)/gu).map((part, index) =>
    part.startsWith("#") ? <span key={index} className="blue font-medium">{part}</span> : <span key={index}>{part}</span>,
  );
}

export default function PostCard({ post }: { post: FeedPost }) {
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [comment, setComment] = useState("");
  const utils = trpc.useUtils();
  const refresh = () => utils.social.feed.invalidate();
  const like = trpc.social.toggleLike.useMutation({ onSuccess: refresh, onError: (e) => toast.error(e.message) });
  const bookmark = trpc.social.toggleBookmark.useMutation({
    onSuccess: (result) => { refresh(); toast.success(result.bookmarked ? "Gönderi kaydedildi" : "Kayıt kaldırıldı"); },
  });
  const comments = trpc.social.comments.useQuery({ postId: post.id }, { enabled: commentsOpen });
  const addComment = trpc.social.addComment.useMutation({
    onSuccess: () => {
      setComment("");
      comments.refetch();
      refresh();
    },
    onError: (e) => toast.error(e.message),
  });

  function submitComment(event: FormEvent) {
    event.preventDefault();
    if (comment.trim()) addComment.mutate({ postId: post.id, content: comment });
  }

  async function share() {
    const data = { title: `${post.author.name} · Aetheris`, text: post.content, url: `${window.location.origin}/?post=${post.id}` };
    try {
      if (navigator.share) await navigator.share(data);
      else { await navigator.clipboard.writeText(`${data.text}\n${data.url}`); toast.success("Gönderi bağlantısı kopyalandı"); }
    } catch { /* Kullanıcı paylaşım penceresini kapatabilir. */ }
  }

  return (
    <article className="border-b border-white/10 px-4 py-6 transition-colors hover:bg-white/[0.015] sm:px-7" id={`post-${post.id}`}>
      <div className="flex gap-3.5">
        <Avatar src={post.author.avatar} name={post.author.name} size={46} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
            <strong className="text-[15px]">{post.author.name}</strong>
            {post.author.isVerified && <VerifiedBadge />}
            <span className="mono muted text-[11px]">@{post.author.handle} · {relativeTime(post.createdAt)}</span>
          </div>
          <p className="mt-3 whitespace-pre-wrap break-words text-[16px] leading-[1.65] text-white/90">{contentWithTags(post.content)}</p>
          {post.imageUrl && <img src={post.imageUrl} alt="Gönderi görseli" className="mt-4 max-h-[520px] w-full rounded-lg border border-white/10 object-cover" loading="lazy" />}
          <div className="mt-4 flex max-w-[420px] items-center justify-between">
            <button className={`icon-btn -ml-2 w-auto gap-2 px-2 ${post.liked ? "text-[#ff6c88]" : ""}`} onClick={() => like.mutate({ postId: post.id })} disabled={like.isPending} aria-label={post.liked ? "Beğeniyi kaldır" : "Beğen"}><Heart size={19} fill={post.liked ? "currentColor" : "none"} /><span className="mono text-xs">{post.likeCount}</span></button>
            <button className="icon-btn w-auto gap-2 px-2" onClick={() => setCommentsOpen(true)} aria-label="Yorumları aç"><MessageCircle size={19} /><span className="mono text-xs">{post.commentCount}</span></button>
            <button className="icon-btn" onClick={share} aria-label="Gönderiyi paylaş"><Share2 size={18} /></button>
            <button className={`icon-btn ${post.bookmarked ? "blue" : ""}`} onClick={() => bookmark.mutate({ postId: post.id })} disabled={bookmark.isPending} aria-label={post.bookmarked ? "Kaydı kaldır" : "Kaydet"}><Bookmark size={19} fill={post.bookmarked ? "currentColor" : "none"} /></button>
          </div>
        </div>
      </div>

      <Dialog open={commentsOpen} onOpenChange={setCommentsOpen}>
        <DialogContent className="max-h-[85dvh] max-w-xl overflow-y-auto border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader><DialogTitle>Sohbet</DialogTitle><DialogDescription className="text-white/50">{post.author.name} adlı kullanıcının gönderisine yorum yap.</DialogDescription></DialogHeader>
          <blockquote className="border-l border-[#40aaff] pl-4 text-sm text-white/75">{post.content}</blockquote>
          <div className="space-y-4 py-2">
            {comments.isLoading && <p className="muted text-sm">Yorumlar yükleniyor…</p>}
            {comments.data?.length === 0 && <p className="muted py-6 text-center text-sm">İlk yorumu sen yaz.</p>}
            {comments.data?.map(({ comment: item, author }) => (
              <div key={item.id} className="flex gap-3"><Avatar src={author.avatar} name={author.name ?? "Üye"} size={34} /><div><div className="flex items-center gap-2"><strong className="text-sm">{author.name}</strong><span className="mono muted text-[10px]">{relativeTime(item.createdAt)}</span></div><p className="mt-1 text-sm text-white/85">{item.content}</p></div></div>
            ))}
          </div>
          <form onSubmit={submitComment} className="flex gap-2 border-t border-white/10 pt-4"><label htmlFor={`comment-${post.id}`} className="sr-only">Yorumun</label><input id={`comment-${post.id}`} className="field" value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder="Sohbete katkı ver…" /><button className="btn-primary px-3" disabled={!comment.trim() || addComment.isPending} aria-label="Yorumu gönder"><Send size={18} /></button></form>
        </DialogContent>
      </Dialog>
    </article>
  );
}
