import { BadgeCheck } from "lucide-react";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-3" aria-label="Aetheris">
      <span className="flex h-8 w-8 items-end justify-center gap-[3px] border border-white/20 p-[7px]" aria-hidden="true">
        <i className="block h-3 w-[3px] bg-white" />
        <i className="block h-5 w-[3px] bg-[#40aaff]" />
        <i className="block h-2 w-[3px] bg-white" />
      </span>
      {!compact && <strong className="text-[17px] font-bold tracking-[0.2em]">AETHERIS</strong>}
    </span>
  );
}

export function VerifiedBadge({ size = 17 }: { size?: number }) {
  return <BadgeCheck size={size} className="inline-block shrink-0 fill-[#40aaff] text-[#121212]" aria-label="Doğrulanmış hesap" />;
}

export function Avatar({ src, name, size = 44 }: { src?: string | null; name: string; size?: number }) {
  return (
    <img
      src={src || `https://api.dicebear.com/9.x/notionists-neutral/svg?seed=${encodeURIComponent(name)}`}
      alt={`${name} profil fotoğrafı`}
      width={size}
      height={size}
      className="avatar shrink-0"
      style={{ width: size, height: size }}
    />
  );
}
