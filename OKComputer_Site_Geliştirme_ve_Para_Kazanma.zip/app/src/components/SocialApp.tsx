import { useEffect, useState, type ComponentType } from "react";
import { Bell, Compass, Crown, HelpCircle, Home, LayoutDashboard, LogOut, Menu, MessageCircle, PlaySquare, RefreshCw, Settings, ShieldCheck, UserRound, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import type { Account } from "@/types";
import { Avatar, Logo, VerifiedBadge } from "./Brand";
import FeedView from "./FeedView";
import { ExploreView, MessagesView, NotificationsView, ReelsView, SupportView } from "./FeatureViews";
import { AdminView, PremiumView, ProfileView, SettingsView } from "./AccountViews";

type View = "feed" | "explore" | "reels" | "messages" | "notifications" | "premium" | "profile" | "settings" | "support" | "admin";
type NavItem = { id: View; label: string; icon: ComponentType<{ size?: number; className?: string }> };

const navItems: NavItem[] = [
  { id: "feed", label: "Akış", icon: Home },
  { id: "explore", label: "Keşfet", icon: Compass },
  { id: "reels", label: "Reels", icon: PlaySquare },
  { id: "messages", label: "Mesajlar", icon: MessageCircle },
  { id: "notifications", label: "Bildirimler", icon: Bell },
  { id: "premium", label: "Aetheris Plus", icon: Crown },
  { id: "profile", label: "Profil", icon: UserRound },
  { id: "settings", label: "Ayarlar", icon: Settings },
  { id: "support", label: "Yardım ve destek", icon: HelpCircle },
];

const titles: Record<View, string> = {
  feed: "Akış", explore: "Keşfet", reels: "Reels", messages: "Mesajlar", notifications: "Bildirimler", premium: "Aetheris Plus", profile: "Profil", settings: "Ayarlar", support: "Yardım ve destek", admin: "Yönetim",
};

export default function SocialApp({ user, onUserChange }: { user: Account; onUserChange: () => void }) {
  const [view, setView] = useState<View>("feed");
  const [drawer, setDrawer] = useState(false);
  const utils = trpc.useUtils();
  const notifications = trpc.social.notifications.useQuery();
  const people = trpc.social.people.useQuery();
  const logout = trpc.account.logout.useMutation({ onSuccess: async () => { await utils.account.me.invalidate(); window.location.reload(); } });
  const unread = notifications.data?.filter((item) => !item.readAt).length ?? 0;
  const items: NavItem[] = user.role === "admin" ? [...navItems, { id: "admin", label: "Yönetim merkezi", icon: LayoutDashboard }] : navItems;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
    setDrawer(false);
  }, [view]);
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === "Escape") setDrawer(false); };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, []);

  function go(next: View) { setView(next); if (next === "premium" || next === "profile") onUserChange(); }
  async function refresh() {
    if (view === "feed" || view === "explore") await utils.social.feed.invalidate();
    if (view === "notifications") await utils.social.notifications.invalidate();
    await utils.account.me.invalidate();
    toast.success("İçerik yenilendi");
  }

  return (
    <div className="app-layout">
      <aside className="app-sidebar">
        <div>
          <button className="mb-8 flex min-h-11 items-center px-2" onClick={() => go("feed")}><Logo /></button>
          <nav className="space-y-1" aria-label="Ana menü">{items.map((item) => { const Icon = item.icon; return <button key={item.id} onClick={() => go(item.id)} className={`flex min-h-12 w-full items-center gap-3 rounded-md px-3 text-left text-[15px] transition-colors ${view === item.id ? "bg-[#40aaff] font-semibold text-[#121212]" : "text-white/60 hover:bg-white/[0.06] hover:text-white"}`}><Icon size={19} /><span>{item.label}</span>{item.id === "notifications" && unread > 0 && <span className={`mono ml-auto text-xs ${view === item.id ? "text-[#121212]" : "blue"}`}>{unread}</span>}</button>; })}</nav>
        </div>
        <div className="border-t border-white/10 pt-4"><button className="flex w-full items-center gap-3 rounded-md p-2 text-left hover:bg-white/[0.05]" onClick={() => go("profile")}><Avatar src={user.avatar} name={user.name} size={40} /><span className="min-w-0 flex-1"><strong className="flex items-center gap-1 truncate text-sm">{user.name}{user.isVerified && <VerifiedBadge size={15} />}</strong><span className="mono muted block truncate text-[10px]">@{user.handle}</span></span></button><button className="btn-ghost mt-2 w-full justify-start text-sm" onClick={() => logout.mutate()} disabled={logout.isPending}><LogOut size={16} />Oturumu kapat</button></div>
      </aside>

      <main className="app-main">
        <header className="sticky top-0 z-30 flex min-h-[70px] items-center justify-between border-b border-white/10 bg-[#121212]/90 px-4 backdrop-blur-xl sm:px-7">
          <div className="flex items-center gap-2"><button className="icon-btn lg:hidden" onClick={() => setDrawer(true)} aria-label="Menüyü aç"><Menu size={21} /></button><h1 className="text-lg font-semibold tracking-[-0.02em]">{titles[view]}</h1></div>
          <div className="flex items-center gap-1"><button className="icon-btn" onClick={refresh} aria-label="İçeriği yenile"><RefreshCw size={18} /></button><button className="icon-btn relative" onClick={() => go("notifications")} aria-label={`${unread} okunmamış bildirim`}><Bell size={19} />{unread > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#40aaff]" />}</button>{user.plan === "free" && <button className="btn-primary ml-1 hidden sm:inline-flex" onClick={() => go("premium")}><Crown size={16} />Plus'a geç</button>}</div>
        </header>

        {view === "feed" && <FeedView user={user} />}
        {view === "explore" && <ExploreView />}
        {view === "reels" && <ReelsView />}
        {view === "messages" && <MessagesView user={user} />}
        {view === "notifications" && <NotificationsView />}
        {view === "premium" && <PremiumView user={user} />}
        {view === "profile" && <ProfileView user={user} onUserChange={onUserChange} />}
        {view === "settings" && <SettingsView user={user} onUserChange={onUserChange} />}
        {view === "support" && <SupportView />}
        {view === "admin" && user.role === "admin" && <AdminView />}
      </main>

      <aside className="app-rail">
        {user.plan === "free" && <section className="checkerband border border-[#40aaff]/25 p-5"><Crown className="blue" size={24} /><h2 className="mt-4 text-xl font-semibold leading-tight">Mavi tik ve daha fazlası.</h2><p className="muted mt-2 text-sm">Plus ile görünürlüğünü ve üretim kapasiteni artır.</p><button className="btn-primary mt-5 w-full" onClick={() => go("premium")}>Planları incele</button></section>}
        <section className="mt-7"><h2 className="mb-3 text-sm font-semibold">Gündem</h2>{["#AetherisPlus", "#üretim", "#tasarım"].map((topic, index) => <button key={topic} className="flex w-full items-center justify-between border-t border-white/10 py-3 text-left hover:bg-white/[0.03]" onClick={() => go("explore")}><span><strong className="blue block text-sm">{topic}</strong><span className="mono muted text-[10px]">Topluluk konusu</span></span><span className="mono muted text-xs">0{index + 1}</span></button>)}</section>
        <section className="mt-7"><h2 className="mb-3 text-sm font-semibold">Topluluktan</h2>{people.data?.slice(0, 3).map((person) => <div key={person.id} className="flex items-center gap-3 border-t border-white/10 py-3"><Avatar src={person.avatar} name={person.name ?? "Üye"} size={36} /><div className="min-w-0"><strong className="flex items-center gap-1 truncate text-xs">{person.name}{person.isVerified && <VerifiedBadge size={13} />}</strong><span className="mono muted text-[10px]">@{person.handle}</span></div></div>)}</section>
        <footer className="mono muted mt-8 text-[10px] leading-relaxed"><p>Topluluk kuralları · Gizlilik · KVKK</p><p className="mt-2">© 2026 Aetheris. Nitelikli bağlantılar için.</p></footer>
      </aside>

      <nav className="mobile-nav" aria-label="Mobil menü">{navItems.slice(0, 4).map((item) => { const Icon = item.icon; return <button key={item.id} className={view === item.id ? "active" : ""} onClick={() => go(item.id)}><Icon size={20} /><span>{item.label}</span></button>; })}<button onClick={() => setDrawer(true)}><Menu size={20} /><span>Menü</span></button></nav>

      {drawer && <div className="mobile-drawer" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setDrawer(false); }}><section className="mobile-drawer-panel" role="dialog" aria-modal="true" aria-label="Tüm menü"><div className="mb-6 flex items-center justify-between"><Logo /><button className="icon-btn" onClick={() => setDrawer(false)} aria-label="Menüyü kapat"><X size={21} /></button></div><div className="mb-5 flex items-center gap-3 border-y border-white/10 py-4"><Avatar src={user.avatar} name={user.name} /><div><strong className="flex items-center gap-2 text-sm">{user.name}{user.isVerified && <VerifiedBadge />}</strong><span className="mono muted text-xs">@{user.handle}</span></div></div><nav className="space-y-1">{items.map((item) => { const Icon = item.icon; return <button key={item.id} className={`flex min-h-12 w-full items-center gap-3 rounded-md px-3 text-left ${view === item.id ? "bg-[#40aaff] text-[#121212]" : "text-white/70"}`} onClick={() => go(item.id)}><Icon size={19} />{item.label}</button>; })}</nav><button className="btn-danger mt-6 w-full" onClick={() => logout.mutate()}><LogOut size={17} />Oturumu kapat</button><div className="mono muted mt-7 flex items-center gap-2 text-[10px]"><ShieldCheck size={14} />Güvenli oturum etkin</div></section></div>}
    </div>
  );
}
