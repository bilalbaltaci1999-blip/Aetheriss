import { useState, type FormEvent } from "react";
import { ArrowLeft, Bell, CheckCheck, Heart, LifeBuoy, MessageCircle, Play, Search, Send, Share2 } from "lucide-react";
import { toast } from "sonner";
import { relativeTime } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { Account } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";
import PostCard from "./PostCard";

export function ExploreView() {
  const [query, setQuery] = useState("");
  const feed = trpc.social.feed.useQuery();
  const people = trpc.social.people.useQuery();
  const normalized = query.toLocaleLowerCase("tr-TR").replace(/^#/, "");
  const filteredPosts = feed.data?.filter((post) => `${post.content} ${post.author.name} ${post.author.handle}`.toLocaleLowerCase("tr-TR").includes(normalized));
  const filteredPeople = people.data?.filter((person) => `${person.name} ${person.handle} ${person.bio}`.toLocaleLowerCase("tr-TR").includes(normalized));
  const topics = ["AetherisPlus", "üretim", "tasarım", "teknoloji"];
  return (
    <div className="view-enter p-4 sm:p-7">
      <div className="relative"><Search className="muted absolute left-4 top-4" size={19} /><label htmlFor="explore-search" className="sr-only">Aetheris'te ara</label><input id="explore-search" className="field pl-12" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Kişi, konu veya etiket ara" /></div>
      {!query && <section className="mt-8"><h2 className="text-xl font-semibold tracking-tight">Bugün konuşulanlar</h2><div className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-white/10 bg-white/10">{topics.map((topic, index) => <button key={topic} className="min-h-28 bg-[#151515] p-4 text-left transition-colors hover:bg-white/[0.06]" onClick={() => setQuery(topic)}><span className="mono muted text-[10px]">0{index + 1} · GÜNDEM</span><strong className="blue mt-3 block">#{topic}</strong></button>)}</div></section>}
      {query && <section className="mt-8"><div className="mb-4 flex items-center justify-between"><h2 className="text-xl font-semibold">“{query}” sonuçları</h2><button className="btn-ghost text-sm" onClick={() => setQuery("")}>Temizle</button></div>{filteredPeople && filteredPeople.length > 0 && <div className="mb-7 space-y-3">{filteredPeople.map((person) => <div key={person.id} className="flex items-center gap-3 border-b border-white/10 pb-3"><Avatar src={person.avatar} name={person.name ?? "Üye"} /><div><strong className="flex items-center gap-2 text-sm">{person.name}{person.isVerified && <VerifiedBadge />}</strong><p className="mono muted text-xs">@{person.handle}</p></div></div>)}</div>}<div className="-mx-4 border-t border-white/10 sm:-mx-7">{filteredPosts?.map((post) => <PostCard key={post.id} post={post} />)}{filteredPosts?.length === 0 && filteredPeople?.length === 0 && <p className="muted p-8 text-center">Bu aramayla eşleşen bir sonuç yok.</p>}</div></section>}
      {!query && <section className="mt-8"><h2 className="mb-2 text-xl font-semibold tracking-tight">Topluluktan seçkiler</h2><p className="muted mb-4 text-sm">Editoryal sıralama, yalnızca etkileşim sayısını değil sohbet kalitesini de öne çıkarır.</p><div className="-mx-4 border-t border-white/10 sm:-mx-7">{feed.data?.slice(0, 3).map((post) => <PostCard key={post.id} post={post} />)}</div></section>}
    </div>
  );
}

const reels = [
  { id: 1, title: "Şehrin ritmini kaydetmek", author: "Selin Yazıcı", handle: "selinyazici", video: "/reels/sehir-ritmi.mp4", poster: "/reels/sehir-ritmi.webp" },
  { id: 2, title: "Işık, hareket ve yeni fikirler", author: "Emre Keskin", handle: "emrekeskin", video: "/reels/isik-hareket.mp4", poster: "/reels/isik-hareket.webp" },
];

export function ReelsView() {
  const [liked, setLiked] = useState<number[]>([]);
  async function shareReel(title: string) {
    try { await navigator.clipboard.writeText(`${title} · ${window.location.origin}`); toast.success("Reels bağlantısı kopyalandı"); } catch { toast.error("Bağlantı kopyalanamadı"); }
  }
  return (
    <div className="view-enter space-y-5 p-4 sm:p-7">
      <p className="mono muted text-xs">REELS / Yaratıcı topluluktan kısa videolar</p>
      {reels.map((reel) => <article key={reel.id} className="relative mx-auto aspect-[9/14] max-h-[76dvh] overflow-hidden rounded-xl border border-white/10 bg-black"><video className="h-full w-full object-cover" src={reel.video} poster={reel.poster} controls playsInline loop preload="metadata" /><div className="pointer-events-none absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black/90 to-transparent" /><div className="pointer-events-none absolute inset-x-0 bottom-0 p-5"><p className="mono text-[11px] text-white/70">@{reel.handle}</p><h2 className="mt-1 max-w-[24ch] text-2xl font-semibold leading-tight">{reel.title}</h2><p className="mt-2 flex items-center gap-2 text-sm text-white/80"><Play size={15} />Oynatmak için video kontrollerini kullan</p></div><div className="absolute right-3 top-3 flex flex-col gap-2"><button className={`icon-btn bg-black/60 text-white ${liked.includes(reel.id) ? "text-[#ff6c88]" : ""}`} onClick={() => setLiked((items) => items.includes(reel.id) ? items.filter((id) => id !== reel.id) : [...items, reel.id])} aria-label="Reels beğen"><Heart fill={liked.includes(reel.id) ? "currentColor" : "none"} size={19} /></button><button className="icon-btn bg-black/60 text-white" onClick={() => shareReel(reel.title)} aria-label="Reels paylaş"><Share2 size={19} /></button></div></article>)}
    </div>
  );
}

export function MessagesView({ user }: { user: Account }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const conversations = trpc.social.conversations.useQuery();
  const active = conversations.data?.find((person) => person.id === selected);
  const messages = trpc.social.conversation.useQuery({ userId: selected ?? 0 }, { enabled: Boolean(selected), refetchInterval: 5000 });
  const send = trpc.social.sendMessage.useMutation({ onSuccess: () => { setMessage(""); messages.refetch(); }, onError: (e) => toast.error(e.message) });
  function submit(event: FormEvent) { event.preventDefault(); if (selected && message.trim()) send.mutate({ recipientId: selected, content: message }); }
  return (
    <div className="view-enter flex h-[calc(100dvh-150px)] min-h-[480px]">
      <aside className={`${selected ? "hidden sm:block" : "block"} w-full border-r border-white/10 sm:w-52`}><p className="mono muted border-b border-white/10 p-4 text-[10px] uppercase">Sohbetler</p>{conversations.data?.map((person) => <button key={person.id} className={`flex w-full items-center gap-3 border-b border-white/5 p-3 text-left hover:bg-white/5 ${selected === person.id ? "bg-white/5" : ""}`} onClick={() => setSelected(person.id)}><Avatar src={person.avatar} name={person.name ?? "Üye"} size={40} /><span className="min-w-0"><strong className="block truncate text-sm">{person.name}</strong><span className="mono muted block truncate text-[10px]">@{person.handle}</span></span></button>)}</aside>
      <section className={`${selected ? "flex" : "hidden sm:flex"} min-w-0 flex-1 flex-col`}>
        {!active ? <div className="m-auto max-w-xs p-8 text-center"><MessageCircle className="blue mx-auto mb-4" size={30} /><h2 className="text-xl font-semibold">Bir sohbet seç</h2><p className="muted mt-2 text-sm">Mesajların hesabınla birlikte güvenle saklanır.</p></div> : <><header className="flex items-center gap-3 border-b border-white/10 p-3"><button className="icon-btn sm:hidden" onClick={() => setSelected(null)} aria-label="Sohbet listesine dön"><ArrowLeft size={19} /></button><Avatar src={active.avatar} name={active.name ?? "Üye"} size={38} /><div><strong className="flex items-center gap-2 text-sm">{active.name}{active.isVerified && <VerifiedBadge />}</strong><span className="mono muted text-[10px]">@{active.handle}</span></div></header><div className="flex-1 space-y-3 overflow-y-auto p-4">{messages.data?.map((item) => <div key={item.id} className={`flex ${item.senderId === user.id ? "justify-end" : "justify-start"}`}><div className={`max-w-[82%] rounded-lg px-3.5 py-2.5 text-sm ${item.senderId === user.id ? "bg-[#40aaff] text-[#121212]" : "bg-white/[0.07] text-white"}`}><p>{item.content}</p><span className={`mono mt-1 block text-[9px] ${item.senderId === user.id ? "text-black/60" : "text-white/45"}`}>{relativeTime(item.createdAt)}</span></div></div>)}{messages.data?.length === 0 && <p className="muted py-12 text-center text-sm">İlk mesajı gönder.</p>}</div><form onSubmit={submit} className="flex gap-2 border-t border-white/10 p-3"><label htmlFor="message-input" className="sr-only">Mesaj</label><input id="message-input" className="field" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Mesajını yaz…" maxLength={1000} /><button className="btn-primary px-3" disabled={!message.trim() || send.isPending} aria-label="Mesajı gönder"><Send size={18} /></button></form></>}
      </section>
    </div>
  );
}

export function NotificationsView() {
  const utils = trpc.useUtils();
  const notifications = trpc.social.notifications.useQuery();
  const markRead = trpc.social.markNotificationsRead.useMutation({ onSuccess: () => utils.social.notifications.invalidate() });
  return <div className="view-enter p-4 sm:p-7"><div className="mb-5 flex items-center justify-between"><p className="mono muted text-xs">{notifications.data?.filter((n) => !n.readAt).length ?? 0} okunmamış bildirim</p><button className="btn-ghost text-sm" onClick={() => markRead.mutate()} disabled={markRead.isPending}><CheckCheck size={16} />Tümünü okundu işaretle</button></div><div className="border-t border-white/10">{notifications.data?.map((item) => <article key={item.id} className={`flex gap-4 border-b border-white/10 py-5 ${!item.readAt ? "bg-[#40aaff]/[0.035]" : "opacity-65"}`}><span className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/10"><Bell size={16} className={item.kind === "billing" ? "lime" : "blue"} /></span><div><h2 className="font-semibold">{item.title}</h2><p className="muted mt-1 text-sm">{item.body}</p><span className="mono muted mt-2 block text-[10px]">{relativeTime(item.createdAt)}</span></div></article>)}{notifications.data?.length === 0 && <p className="muted py-12 text-center">Henüz bildirimin yok.</p>}</div></div>;
}

export function SupportView() {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const utils = trpc.useUtils();
  const tickets = trpc.social.tickets.useQuery();
  const create = trpc.social.createTicket.useMutation({ onSuccess: () => { setSubject(""); setMessage(""); utils.social.tickets.invalidate(); toast.success("Destek talebin oluşturuldu"); }, onError: (e) => toast.error(e.message) });
  function submit(event: FormEvent) { event.preventDefault(); create.mutate({ subject, message }); }
  return <div className="view-enter p-4 sm:p-7"><section className="max-w-2xl"><LifeBuoy className="blue mb-5" size={30} /><h2 className="text-2xl font-semibold tracking-tight">Nasıl yardımcı olabiliriz?</h2><p className="muted mt-2 text-sm">Hesap, güvenlik veya ödeme sorununu açıkça anlat. Talebine buradan yanıt vereceğiz.</p><form onSubmit={submit} className="mt-7 space-y-4"><div><label htmlFor="ticket-subject" className="field-label">Konu</label><input id="ticket-subject" className="field" value={subject} onChange={(e) => setSubject(e.target.value)} required minLength={3} placeholder="Örn. Plus ödemem hakkında" /></div><div><label htmlFor="ticket-message" className="field-label">Açıklama</label><textarea id="ticket-message" className="field" value={message} onChange={(e) => setMessage(e.target.value)} required minLength={10} placeholder="Sorunu ve varsa sipariş kodunu yaz…" /></div><button className="btn-primary" disabled={create.isPending}>Talebi gönder<Send size={17} /></button></form></section><section className="mt-10"><h2 className="mb-4 text-xl font-semibold">Taleplerin</h2><div className="border-t border-white/10">{tickets.data?.map((ticket) => <article key={ticket.id} className="border-b border-white/10 py-4"><div className="flex items-start justify-between gap-4"><div><span className="mono muted text-[10px]">#{ticket.id} · {relativeTime(ticket.createdAt)}</span><h3 className="mt-1 font-semibold">{ticket.subject}</h3><p className="muted mt-1 text-sm">{ticket.message}</p></div><span className={`badge ${ticket.status === "open" ? "status-warning" : "status-success"}`}>{ticket.status === "open" ? "Açık" : ticket.status === "answered" ? "Yanıtlandı" : "Kapalı"}</span></div></article>)}{tickets.data?.length === 0 && <p className="muted py-8 text-sm">Açık destek talebin yok.</p>}</div></section></div>;
}
