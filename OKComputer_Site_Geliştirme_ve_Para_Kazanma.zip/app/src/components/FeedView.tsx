import { useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Hash, ImagePlus, Plus, Send, X } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/providers/trpc";
import type { Account, Person } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";
import PostCard from "./PostCard";

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function FeedView({ user }: { user: Account }) {
  const [content, setContent] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [story, setStory] = useState<Person | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const utils = trpc.useUtils();
  const feed = trpc.social.feed.useQuery(undefined, { refetchInterval: 15000 });
  const people = trpc.social.people.useQuery();
  const upload = trpc.storage.uploadImage.useMutation();
  const create = trpc.social.createPost.useMutation({
    onSuccess: () => {
      setContent("");
      setFile(null);
      setPreview("");
      utils.social.feed.invalidate();
      toast.success("Gönderin akışta");
    },
    onError: (error) => toast.error(error.message),
  });
  const maxLength = user.plan === "plus" ? 1200 : 500;

  function selectFile(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (selected.size > 8 * 1024 * 1024) { toast.error("Görsel en fazla 8 MB olabilir"); return; }
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!content.trim()) { toast.error("Önce birkaç satır yaz"); return; }
    try {
      let imageKey: string | undefined;
      if (file) {
        toast.loading("Görsel güvenli depoya yükleniyor…", { id: "upload" });
        const saved = await upload.mutateAsync({ name: file.name, contentBase64: await fileToBase64(file), contentType: file.type });
        imageKey = saved.key;
        toast.dismiss("upload");
      }
      create.mutate({ content, imageKey });
    } catch (error) {
      toast.dismiss("upload");
      toast.error(error instanceof Error ? error.message : "Görsel yüklenemedi");
    }
  }

  return (
    <div className="view-enter">
      <section className="border-b border-white/10 px-4 py-5 sm:px-7" aria-label="Pulse hikayeleri">
        <div className="flex items-center gap-4 overflow-x-auto pb-1">
          <button className="group flex shrink-0 flex-col items-center gap-2" onClick={() => inputRef.current?.focus()}><span className="flex h-14 w-14 items-center justify-center rounded-full border border-dashed border-[#40aaff] text-[#40aaff] transition-transform group-hover:scale-105"><Plus size={20} /></span><span className="mono muted text-[10px]">Pulse ekle</span></button>
          {people.data?.slice(0, 7).map((person) => <button key={person.id} className="group flex w-16 shrink-0 flex-col items-center gap-2" onClick={() => setStory(person)}><span className="rounded-full border border-[#40aaff] p-0.5 transition-transform group-hover:scale-105"><Avatar src={person.avatar} name={person.name ?? "Üye"} size={52} /></span><span className="mono muted max-w-full truncate text-[10px]">{person.name?.split(" ")[0]}</span></button>)}
        </div>
      </section>

      <section className="border-b border-white/10 px-4 py-6 sm:px-7">
        <form onSubmit={submit}>
          <div className="flex gap-3.5"><Avatar src={user.avatar} name={user.name} size={46} /><div className="min-w-0 flex-1"><label htmlFor="new-post" className="sr-only">Yeni gönderi</label><textarea ref={inputRef} id="new-post" className="field min-h-[108px] border-0 bg-transparent px-0 text-lg focus:bg-transparent" value={content} onChange={(e) => setContent(e.target.value)} maxLength={maxLength} placeholder="Topluluğunla ne paylaşmak istersin?" /></div></div>
          {preview && <div className="relative mt-4 overflow-hidden rounded-lg border border-white/10"><img src={preview} alt="Yüklenecek görsel önizlemesi" className="max-h-80 w-full object-cover" /><button type="button" className="icon-btn absolute right-2 top-2 bg-black/70 text-white" onClick={() => { setFile(null); setPreview(""); }} aria-label="Görseli kaldır"><X size={18} /></button></div>}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4">
            <div className="flex items-center gap-1"><label className="icon-btn cursor-pointer text-[#40aaff]" title="Görsel ekle"><ImagePlus size={20} /><input type="file" className="hidden" accept="image/jpeg,image/png,image/webp,image/gif" onChange={selectFile} /></label><button type="button" className="icon-btn text-[#40aaff]" onClick={() => { setContent((value) => `${value}${value ? " " : ""}#Aetheris `); inputRef.current?.focus(); }} aria-label="Etiket ekle"><Hash size={20} /></button><span className={`mono ml-2 text-[10px] ${content.length > maxLength * 0.9 ? "text-[#ffd866]" : "muted"}`}>{content.length}/{maxLength}</span></div>
            <button className="btn-primary" disabled={!content.trim() || create.isPending || upload.isPending}>{create.isPending || upload.isPending ? "Paylaşılıyor…" : "Paylaş"}<Send size={17} /></button>
          </div>
          {user.plan === "free" && <p className="mono muted mt-3 text-[10px]">Plus ile 1.200 karaktere kadar yazabilirsin.</p>}
        </form>
      </section>

      <section aria-label="Gönderi akışı">
        {feed.isLoading && <div className="space-y-5 p-7">{[1, 2, 3].map((item) => <div key={item} className="skeleton h-36 rounded-lg" />)}</div>}
        {feed.isError && <div className="p-8 text-center"><p className="text-red-200">Akış yüklenemedi.</p><button className="btn-secondary mt-4" onClick={() => feed.refetch()}>Tekrar dene</button></div>}
        {feed.data?.map((post) => <PostCard key={post.id} post={post} />)}
        {feed.data?.length === 0 && <div className="p-12 text-center"><p className="text-xl font-semibold">Akış henüz sessiz.</p><p className="muted mt-2">İlk gönderiyi paylaşarak sohbeti başlat.</p></div>}
      </section>

      <Dialog open={Boolean(story)} onOpenChange={(open) => !open && setStory(null)}>
        <DialogContent className="checkerband min-h-[60dvh] border-white/10 bg-[#121212] text-white sm:rounded-lg">
          {story && <><DialogHeader><div className="flex items-center gap-3"><Avatar src={story.avatar} name={story.name ?? "Üye"} /><div><DialogTitle className="flex items-center gap-2">{story.name}{story.isVerified && <VerifiedBadge />}</DialogTitle><DialogDescription className="mono text-white/50">@{story.handle} · Pulse</DialogDescription></div></div></DialogHeader><div className="flex min-h-[300px] items-center"><p className="max-w-[25ch] text-3xl font-medium leading-tight tracking-[-0.04em]">{story.bio}</p></div></>}
        </DialogContent>
      </Dialog>
    </div>
  );
}
