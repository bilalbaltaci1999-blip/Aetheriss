export function relativeTime(value: Date | string) {
  const date = value instanceof Date ? value : new Date(value);
  const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return "şimdi";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} dk`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} sa`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} g`;
  return new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "short" }).format(date);
}

export function money(kurus: number) {
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
}

export const orderStatus: Record<string, { label: string; className: string }> = {
  awaiting_payment: { label: "Ödeme bekleniyor", className: "status-warning" },
  pending_review: { label: "İncelemede", className: "status-info" },
  active: { label: "Tamamlandı", className: "status-success" },
  rejected: { label: "Reddedildi", className: "status-danger" },
};
