import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";

export type RouterOutputs = inferRouterOutputs<AppRouter>;
export type Account = NonNullable<RouterOutputs["account"]["me"]>;
export type FeedPost = RouterOutputs["social"]["feed"][number];
export type Person = RouterOutputs["social"]["people"][number];
export type Order = RouterOutputs["commerce"]["myOrders"][number];
