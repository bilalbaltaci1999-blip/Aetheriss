import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import AuthScreen from "@/components/AuthScreen";
import SocialApp from "@/components/SocialApp";
import { Logo } from "@/components/Brand";

export default function Home() {
  const [resetToken, setResetToken] = useState<string | null>(null);
  const utils = trpc.useUtils();
  const account = trpc.account.me.useQuery(undefined, { retry: false, refetchInterval: 60000 });

  useEffect(() => {
    setResetToken(new URLSearchParams(window.location.search).get("reset"));
  }, []);

  const refreshAccount = async () => {
    await utils.account.me.invalidate();
  };

  if (account.isLoading) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <div className="flex flex-col items-center gap-5"><Logo /><div className="h-0.5 w-36 overflow-hidden bg-white/10"><div className="h-full w-1/2 animate-pulse bg-[#40aaff]" /></div><span className="mono muted text-xs">Güvenli oturum kontrol ediliyor</span></div>
      </main>
    );
  }

  if (!account.data) {
    return <AuthScreen resetToken={resetToken} onAuthenticated={refreshAccount} />;
  }

  return <SocialApp user={account.data} onUserChange={refreshAccount} />;
}
